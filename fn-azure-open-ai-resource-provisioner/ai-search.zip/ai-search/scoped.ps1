$tenantId = "e65107ae-deaa-4f76-b79e-c4b5067a5929"
$clientId = "7d5a5213-8466-44f4-afbf-08fbf0642559"
$clientSecret = "tYX8Q~_Ovon7xXVpk523qKqwIa0nQNUIRPUArdx8"
$resourceUrl = "https://cognitiveservices.azure.com/"

$tokenEndpoint = "https://login.microsoftonline.com/$tenantId/oauth2/token"
$body = @{
    grant_type    = "client_credentials"
    client_id     = $clientId
    client_secret = $clientSecret
    resource      = $resourceUrl
}

$responseToken = Invoke-RestMethod -Uri $tokenEndpoint -Method Post -Body $body
$accessToken = $responseToken.access_token