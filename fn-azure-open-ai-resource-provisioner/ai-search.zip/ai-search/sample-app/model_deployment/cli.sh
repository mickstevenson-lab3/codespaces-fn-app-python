az cognitiveservices account deployment create --name leif-azureopen-ai \
  --resource-group poc-wbc-exampleapp \
  --deployment-name scripted \
  --model-name text-embedding-ada-002 \
  --model-version "2" \
  --model-format "OpenAI" \
  --sku-capacity "1" \
  --sku-name "Standard"