#!/usr/bin/env bash

set -euo pipefail

clientId=$(cat .client_id)
clientSecret=$(cat .client_secret)
tenantId=$(cat .tenant_id)
resourceUrl="https://cognitiveservices.azure.com/"
tokenEndpoint="https://login.microsoftonline.com/$tenantId/oauth2/token"

body=$(
cat <<EOF
{
  "grant_type":    "client_credentials",
  "client_id":     "${clientId}",
  "client_secret": "${clientSecret}",
  "resource":      "${resourceUrl}"
}
EOF
)

echo $body > ./body

curl -v --location --request POST "${tokenEndpoint}" --data "@./body" --trace-ascii -

#rm .body

#
#bearer=$(az account get-access-token --scope https://search.azure.com/.default | jq -r '.accessToken')
#
#local result
#
#echo "curl -v --location --request PUT ${args[search_endpoint]}/deployments('${args[deployment_name]}')?api-version=2023-11-01 \
#            --header 'Content-Type: application/json' \
#            --header Authorization: Bearer ${bearer} \
#            --data ${args[deployment_json]}"
#
#result=$(curl -v --location --request PUT "${args[openai_endpoint]}/deployments('${args[deployment_name]}')?api-version=2023-11-01" \
#              --header 'Content-Type: application/json' \
#              --header "Authorization: Bearer ${bearer}" \
#              --data "${args[deployment_json]}"
#)
#
#echo "Display the result"
#
#echo "result == ${result}"


exit 0
